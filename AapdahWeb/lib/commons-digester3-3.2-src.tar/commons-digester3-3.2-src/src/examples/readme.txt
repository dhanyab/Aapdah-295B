The subdirectories of this directory divide the examples into topics.

The examples in API deal with the main Digester API. 

The xmlrules directory deals with the xmlrules extension which allows
the digester rules to be configured via an xml file. This allows the
mapping between input xml and java objects to be modified without
recompilation of any source code.
